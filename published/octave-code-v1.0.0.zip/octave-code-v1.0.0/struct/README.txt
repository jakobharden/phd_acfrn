All files in this directory have been published before by Jakob Harden (Graz University of Technology).
See also DOI: https://doi.org/10.3217/d3p6m-w7d64
 
