All files in this directory have been published before by Jakob Harden.
DOI: https://doi.org/10.3217/d3p6m-w7d64
 
